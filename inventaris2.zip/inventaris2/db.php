<?php

$koneksi = mysqli_connect("localhost", "root", "", "inventaris1");

if (!$koneksi) {
    die("Koneksi gagal!");
}

?>